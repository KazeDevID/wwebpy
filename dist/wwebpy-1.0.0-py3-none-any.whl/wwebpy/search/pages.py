from wwebpy.pages import BasePage


class SearchPage(BasePage):
    pass
