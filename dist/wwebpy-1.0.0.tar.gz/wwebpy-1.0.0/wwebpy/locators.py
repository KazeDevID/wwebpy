from selenium.webdriver.common.by import By


class WelcomeLocators(object):
    WELCOME = (By.CSS_SELECTOR, "._1kdBg")
