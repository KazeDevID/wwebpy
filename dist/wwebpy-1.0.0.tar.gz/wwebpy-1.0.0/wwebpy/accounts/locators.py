from selenium.webdriver.common.by import By

# Locators
class LoginLocators(object):
    REMEMBER_ME_CHECKBOX = (By.NAME, "rememberMe")
