from selenium.webdriver.common.by import By


class SearchLocators(object):
    SEARCH = (By.CSS_SELECTOR, "._2EoyP")
    # CHATS = (,)
    # GROUPS = (,)
    # CONTACTS = (,)  # Membuat room chat baru
    # MESSAGES = (,)
